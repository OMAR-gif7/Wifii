package com.wifiusagetester.app

import android.app.Activity
import android.app.AppOpsManager
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkStats
import android.net.NetworkStatsManager
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Button
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale("ar"))

    // الفترة الافتراضية: من أول الشهر الحالي حتى الآن
    private val startCal: Calendar = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_MONTH, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    private val endCal: Calendar = Calendar.getInstance()

    private lateinit var tvPermission: TextView
    private lateinit var tvWifi: TextView
    private lateinit var tvRange: TextView
    private lateinit var tvDownload: TextView
    private lateinit var tvUpload: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tvError: TextView
    private lateinit var tvDevice: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvPermission = findViewById(R.id.tvPermission)
        tvWifi = findViewById(R.id.tvWifi)
        tvRange = findViewById(R.id.tvRange)
        tvDownload = findViewById(R.id.tvDownload)
        tvUpload = findViewById(R.id.tvUpload)
        tvTotal = findViewById(R.id.tvTotal)
        tvError = findViewById(R.id.tvError)
        tvDevice = findViewById(R.id.tvDevice)

        findViewById<Button>(R.id.btnOpenSettings).setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        findViewById<Button>(R.id.btnPickStart).setOnClickListener { pickDate(isStart = true) }
        findViewById<Button>(R.id.btnPickEnd).setOnClickListener { pickDate(isStart = false) }
        findViewById<Button>(R.id.btnRefresh).setOnClickListener { refresh() }

        tvDevice.text = "الجهاز: ${Build.MANUFACTURER} ${Build.MODEL}
" +
                "Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})
" +
                "التصحيح الأمني: ${Build.VERSION.SECURITY_PATCH}"
        tvDownload.text = "Download: —"
        tvUpload.text = "Upload: —"
        tvTotal.text = "Total: —"
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStatus()
        updateRangeText()
    }

    // ===== 1) فحص صلاحية Usage Access =====
    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun refreshPermissionStatus() {
        val granted = hasUsageAccess()
        tvPermission.text = if (granted) "Usage Access: مفعّل ✅" else "Usage Access: غير مفعّل ❌"
        tvPermission.setTextColor(if (granted) 0xFF2E7D32.toInt() else 0xFFC62828.toInt())
    }

    // ===== 2) حالة Wi-Fi الحالية (معلومة فقط) =====
    private fun isWifiConnected(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    // ===== 3) اختيار الفترة الزمنية =====
    private fun pickDate(isStart: Boolean) {
        val cal = if (isStart) startCal else endCal
        DatePickerDialog(
            this,
            { _, y, m, d ->
                cal.set(Calendar.YEAR, y)
                cal.set(Calendar.MONTH, m)
                cal.set(Calendar.DAY_OF_MONTH, d)
                if (isStart) {
                    cal.set(Calendar.HOUR_OF_DAY, 0)
                    cal.set(Calendar.MINUTE, 0)
                    cal.set(Calendar.SECOND, 0)
                    cal.set(Calendar.MILLISECOND, 0)
                } else {
                    cal.set(Calendar.HOUR_OF_DAY, 23)
                    cal.set(Calendar.MINUTE, 59)
                    cal.set(Calendar.SECOND, 59)
                    cal.set(Calendar.MILLISECOND, 999)
                }
                updateRangeText()
            },
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun updateRangeText() {
        tvRange.text = "الفترة:  ${dateFormat.format(startCal.time)}   ←   ${dateFormat.format(endCal.time)}"
    }

    // ===== 4) القراءة الفعلية عبر NetworkStatsManager =====
    private fun refresh() {
        tvError.text = ""
        refreshPermissionStatus()
        tvWifi.text = if (isWifiConnected())
            "Wi-Fi الآن: متصل ✅ (القراءة تشمل كل Wi-Fi في الفترة، الاتصال الحالي غير شرط)"
        else
            "Wi-Fi الآن: غير متصل ❌ (القراءة تشمل كل Wi-Fi في الفترة، الاتصال الحالي غير شرط)"
        updateRangeText()

        if (!hasUsageAccess()) {
            showError("صلاحية Usage Access غير مفعّلة.
اضغط زر فتح الإعدادات وفعّلها للتطبيق ثم اضغط Refresh.")
            return
        }

        val start = startCal.timeInMillis
        val end = endCal.timeInMillis
        if (end <= start) {
            showError("تاريخ النهاية يجب أن يكون بعد تاريخ البداية.")
            return
        }

        try {
            val nsm = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            // الإحصائيات على مستوى الجهاز كاملًا عبر Wi-Fi فقط
            val bucket: NetworkStats.Bucket = nsm.querySummaryForDevice(
                ConnectivityManager.TYPE_WIFI,  // = NetworkStatsManager.NETWORK_TYPE_WIFI
                null,                           // subscriberId غير مطلوب لـ Wi-Fi
                start,
                end
            )
            val rx = bucket.rxBytes   // التحميل
            val tx = bucket.txBytes   // الرفع

            tvDownload.text = "Download:  ${formatBytes(rx)}"
            tvUpload.text = "Upload:  ${formatBytes(tx)}"
            tvTotal.text = "Total:  ${formatBytes(rx + tx)}"
        } catch (se: SecurityException) {
            showError("SecurityException: ${se.message}
النظام يرفض القراءة رغم إظهار الصلاحية مفعّلة — وجود قيد من Realme UI.")
        } catch (e: Exception) {
            showError("${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun formatBytes(bytes: Long): String =
        Formatter.formatShortFileSize(this, bytes)

    private fun showError(msg: String) {
        tvError.text = "⚠️ خطأ:
$msg"
        tvError.setTextColor(0xFFC62828.toInt())
    }
}
